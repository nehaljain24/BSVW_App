using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BesucherVerwaltung.Data;

/// <summary>
/// Summary description for Mitarbeiter
/// </summary>
public class Mitarbeiter
{
	private int mitarbeiterID;
	private int standortID;
	private string nachname;
	private string vorname;
	private string persNr;
	private int fkz;
	private string anrede;
	private string titel;
	private string telefon;
	private string mailAdresse;
	private string abteilung;
	private string mobilTelefon;
	private string dienstelle;
	private string bau;
	private string raum;
	private DateTime aenderungsDatum;
	private string scd_ma_id;
	private bool loeschen;
	private string etage;
	private string ortswahl;
	private string amtsnummer;
	private string faxNummer;

	public int MitarbeiterID
	{
		get { return mitarbeiterID; }
		set { mitarbeiterID = value; }
	}

	public int StandortID
	{
		get { return standortID; }
		set { standortID = value; }
	}

	public string Nachname
	{
		get { return nachname; }
		set { nachname = value; }
	}

	public string Vorname
	{
		get { return vorname; }
		set { vorname = value; }
	}

	public string PersNr
	{
		get { return persNr; }
		set { persNr = value; }
	}

	public int Fkz
	{
		get { return fkz; }
		set { fkz = value; }
	}

	public string Anrede
	{
		get { return anrede; }
		set { anrede = value; }
	}

	public string Titel
	{
		get { return titel; }
		set { titel = value; }
	}

	public string Telefon
	{
		get { return telefon; }
		set { telefon = value; }
	}

	public string MailAdresse
	{
		get { return mailAdresse; }
		set { mailAdresse = value; }
	}

	public string Abteilung
	{
		get { return abteilung; }
		set { abteilung = value; }
	}

	public string MobilTelefon
	{
		get { return mobilTelefon; }
		set { mobilTelefon = value; }
	}

	public string Dienstelle
	{
		get { return dienstelle; }
		set { dienstelle = value; }
	}

	public string Bau
	{
		get { return bau; }
		set { bau = value; }
	}

	public string Raum
	{
		get { return raum; }
		set { raum = value; }
	}

	public DateTime AenderungsDatum
	{
		get { return aenderungsDatum; }
		set { aenderungsDatum = value; }
	}

	public string Scd_ma_id
	{
		get { return scd_ma_id; }
		set { scd_ma_id = value; }
	}

	public bool Loeschen
	{
		get { return loeschen; }
		set { loeschen = value; }
	}

	public string Etage
	{
		get { return etage; }
		set { etage = value; }
	}

	public string Ortswahl
	{
		get { return ortswahl; }
		set { ortswahl = value; }
	}

	public string Amtsnummer
	{
		get { return amtsnummer; }
		set { amtsnummer = value; }
	}

	public string FaxNummer
	{
		get { return faxNummer; }
		set { faxNummer = value; }
	}

	public Mitarbeiter()
	{
	}

	public Mitarbeiter(int standortID, string nachname, string vorname, string persNr, int fkz, string anrede, string titel, string telefon, string mailAdresse, string abteilung, string mobilTelefon, string dienstelle, string bau, string raum, DateTime aenderungsDatum, string scd_ma_id, bool loeschen, string etage, string ortswahl, string autonummer, string faxNummer)
	{
		this.standortID = standortID;
		this.nachname = nachname;
		this.vorname = vorname;
		this.persNr = persNr;
		this.fkz = fkz;
		this.anrede = anrede;
		this.titel = titel;
		this.telefon = telefon;
		this.mailAdresse = mailAdresse;
		this.abteilung = abteilung;
		this.mobilTelefon = mobilTelefon;
		this.dienstelle = dienstelle;
		this.bau = bau;
		this.raum = raum;
		this.aenderungsDatum = aenderungsDatum;
		this.scd_ma_id = scd_ma_id;
		this.loeschen = loeschen;
		this.etage = etage;
		this.ortswahl = ortswahl;
		this.amtsnummer = autonummer;
		this.faxNummer = faxNummer;
	}

	private static Mitarbeiter FromDataRow(besan2DataSet.GetMitarbeiterFromIDRow r)
	{
		if (r == null)
		{
			return null;
		}

		Mitarbeiter m = new Mitarbeiter();
		m.mitarbeiterID = r.MitarbeiterID;
		m.standortID = r.StandortID;
		m.Nachname = r.Nachname;
		m.Vorname = r.IsVornameNull() ? String.Empty : r.Vorname;
		m.persNr = r.PersNr;
		m.fkz = r.FKz;
		m.anrede = r.IsAnredeNull() ? String.Empty : r.Anrede;
		m.titel = r.IsTitelNull() ? String.Empty : r.Titel;
		m.telefon = r.IsTelefonNull() ? String.Empty : r.Telefon;
		m.mailAdresse = r.IsMailAdresseNull() ? String.Empty : r.MailAdresse;
		m.abteilung = r.IsAbteilungNull() ? String.Empty : r.Abteilung;
		m.MobilTelefon = r.IsMobilTelefonNull() ? String.Empty : r.MobilTelefon;
		m.dienstelle = r.IsDienststelleNull() ? String.Empty : r.Dienststelle;
		m.bau = r.IsBauNull() ? String.Empty : r.Bau;
		m.raum = r.IsRaumNull() ? String.Empty : r.Raum;
		m.aenderungsDatum = r.IsAenderungDatumNull() ? DateTime.MinValue : r.AenderungDatum;
		m.scd_ma_id = r.IsSCD_MA_IDNull() ? String.Empty : r.SCD_MA_ID;
		m.loeschen = r.Loeschen;
		m.etage = r.IsEtageNull() ? String.Empty : r.Etage;
		m.ortswahl = r.IsOrtsvorwahlNull() ? String.Empty : r.Ortsvorwahl;
		m.amtsnummer = r.IsAmtsnummerNull() ? String.Empty : r.Amtsnummer;
		m.faxNummer = r.IsFaxNrNull() ? String.Empty : r.FaxNr;
		return m;
	}

	public static Mitarbeiter Get(int id)
	{
		DataAccess da = new DataAccess();
		return FromDataRow(da.GetMitarbeiterFromID(id));
	}

	public static Mitarbeiter Get(string personalNumber, int fKz)
	{
		DataAccess da = new DataAccess();
		besan2DataSet.GetMitarbeiterRow r = da.GetMitarbeiter(personalNumber, fKz);
		if (r != null)
		{
			Mitarbeiter m = new Mitarbeiter();
			m.mitarbeiterID = r.MitarbeiterID;
			m.standortID = r.StandortID;
			m.Nachname = r.Nachname;
			m.Vorname = r.IsVornameNull() ? String.Empty : r.Vorname;
			m.persNr = r.PersNr;
			m.fkz = r.FKz;
			m.anrede = r.IsAnredeNull() ? String.Empty : r.Anrede;
			m.titel = r.IsTitelNull() ? String.Empty : r.Titel;
			m.telefon = r.IsTelefonNull() ? String.Empty : r.Telefon;
			m.mailAdresse = r.IsMailAdresseNull() ? String.Empty : r.MailAdresse;
			m.abteilung = r.IsAbteilungNull() ? String.Empty : r.Abteilung;
			m.MobilTelefon = r.IsMobilTelefonNull() ? String.Empty : r.MobilTelefon;
			m.dienstelle = r.IsDienststelleNull() ? String.Empty : r.Dienststelle;
			m.bau = r.IsBauNull() ? String.Empty : r.Bau;
			m.raum = r.IsRaumNull() ? String.Empty : r.Raum;
			m.aenderungsDatum = r.IsAenderungDatumNull() ? DateTime.MinValue : r.AenderungDatum;
			m.scd_ma_id = r.IsSCD_MA_IDNull() ? String.Empty : r.SCD_MA_ID;
			m.loeschen = r.Loeschen;
			m.etage = r.IsEtageNull() ? String.Empty : r.Etage;
			m.ortswahl = r.IsOrtsvorwahlNull() ? String.Empty : r.Ortsvorwahl;
			m.amtsnummer = r.IsAmtsnummerNull() ? String.Empty : r.Amtsnummer;
			m.faxNummer = r.IsFaxNrNull() ? String.Empty : r.FaxNr;
			return m;
		}

		return null;
	}

	public static Mitarbeiter Get(string surname, string name, string personalNumber, int fKz)
	{
		DataAccess da = new DataAccess();
		besan2DataSet.GetMitarbeiterFromNameRow r = da.GetMitarbeiterFromName(surname, name, personalNumber, fKz);
		if (r != null)
		{
			Mitarbeiter m = new Mitarbeiter();
			m.mitarbeiterID = r.MitarbeiterID;
			m.standortID = r.StandortID;
			m.Nachname = r.Nachname;
			m.Vorname = r.IsVornameNull() ? String.Empty : r.Vorname;
			m.persNr = r.PersNr;
			m.fkz = r.FKz;
			m.anrede = r.IsAnredeNull() ? String.Empty : r.Anrede;
			m.titel = r.IsTitelNull() ? String.Empty : r.Titel;
			m.telefon = r.IsTelefonNull() ? String.Empty : r.Telefon;
			m.mailAdresse = r.IsMailAdresseNull() ? String.Empty : r.MailAdresse;
			m.abteilung = r.IsAbteilungNull() ? String.Empty : r.Abteilung;
			m.MobilTelefon = r.IsMobilTelefonNull() ? String.Empty : r.MobilTelefon;
			m.dienstelle = r.IsDienststelleNull() ? String.Empty : r.Dienststelle;
			m.bau = r.IsBauNull() ? String.Empty : r.Bau;
			m.raum = r.IsRaumNull() ? String.Empty : r.Raum;
			m.aenderungsDatum = r.IsAenderungDatumNull() ? DateTime.MinValue : r.AenderungDatum;
			m.scd_ma_id = r.IsSCD_MA_IDNull() ? String.Empty : r.SCD_MA_ID;
			m.loeschen = r.Loeschen;
			m.etage = r.IsEtageNull() ? String.Empty : r.Etage;
			m.ortswahl = r.IsOrtsvorwahlNull() ? String.Empty : r.Ortsvorwahl;
			m.amtsnummer = r.IsAmtsnummerNull() ? String.Empty : r.Amtsnummer;
			m.faxNummer = r.IsFaxNrNull() ? String.Empty : r.FaxNr;
			return m;
		}

		return null;
	}
}