using System.Globalization;
using System.Threading;

/// <summary>
/// This is a custom class derived from page class in order to implement localization easily for all the
/// pages in this project
/// </summary>
public class BesanPage : System.Web.UI.Page
{
    public BesanPage()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    protected override void InitializeCulture()
    {
        base.InitializeCulture();
        System.Web.HttpCookie cookie = Request.Cookies["besanlanguage"];
        if (cookie == null)
        {
            cookie = new System.Web.HttpCookie("besanlanguage");
            cookie["balang"] = Thread.CurrentThread.CurrentCulture.Name;
            cookie.Expires = System.DateTime.Now.AddDays(7);
            Response.AppendCookie(cookie);
        }
        string lang = cookie["balang"].ToString();
        
        Thread.CurrentThread.CurrentUICulture = new CultureInfo(lang);
        Thread.CurrentThread.CurrentCulture = new CultureInfo(lang);
    }
   /* protected override void OnLoad(System.EventArgs e)
    {
        base.OnLoad(e);
    }*/
}
