using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;

/// <summary>
/// Summary description for Global
/// </summary>
public class Global
{
    

    public static string GetDatum()
    {
        string datum = WebConfigurationManager.AppSettings.Get("footerDatum");
        return datum;
    }
}
