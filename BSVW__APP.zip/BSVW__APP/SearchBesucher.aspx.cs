using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BesucherVerwaltung.Data;


public partial class SearchBesucher : Page
{
    public string nachnamestring;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)

            if (Session["MitarbeiterID"] != null)
            {
                nachnamestring = (string)Session["nachnamestring"];
                BindBesucherTable(nachnamestring);
            }
            else
            {
                Response.Redirect("LoginForm.aspx");
            }
        Response.Cache.SetNoStore();
        Response.Cache.SetExpires(DateTime.Now.AddMilliseconds(-500));
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.AppendHeader("Pragma", "no-cache");
    }

    private void BindBesucherTable(string nachnamestring)
    {

        besan2DataSet.GetBesucherListDataTable table = Database.DataAccess.GetBesucherList(nachnamestring);
        /* table.VornameColumn.ColumnMapping = MappingType.Hidden;
           table.NachnameColumn.ColumnMapping = MappingType.Hidden;*/
        table.NameColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String7");
        table.AnredeColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String12");
        table.TitelColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String13");
        table.FirmaColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String3");
        table.TelefonColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String14");
        table.SicherheitshinweisColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String15");
        table.AusweisNrColumn.ColumnName = (string)GetGlobalResourceObject("Language", "String16");
        besucherList.TableClass = "listTable";
        besucherList.ValueMember = "BesucherID";
        besucherList.DataSource = table;
    }
    protected void besucherList_SelectedRowChanged(object sender, BesucherVerwaltung.Controls.RowChangedEventArgs e)
    {
        BesucherVerwaltung.Controls.CustomTable table = (BesucherVerwaltung.Controls.CustomTable)sender;
        //Session["SelectedBesucher"] = (int)table.SelectedValue;
       // this.ClientScript.RegisterStartupScript(typeof(SearchBesucher), "Close", "Close()", true);
        HiddenField1.Value = table.SelectedValue.ToString();

        this.ClientScript.RegisterStartupScript(besucherList.GetType(), "Close", @"Close('HiddenField1');", true);
        
    }
}